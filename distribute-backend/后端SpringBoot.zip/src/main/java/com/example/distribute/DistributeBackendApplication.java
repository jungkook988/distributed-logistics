package com.example.distribute;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DistributeBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(DistributeBackendApplication.class, args);
	}

}
