package com.example.distribute;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DistributeBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
