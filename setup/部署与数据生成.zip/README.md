# 启动 HBase Master 和 RegionServer
start-hbase.sh

# 启动 Thrift 服务
hbase-daemon.sh start thrift
